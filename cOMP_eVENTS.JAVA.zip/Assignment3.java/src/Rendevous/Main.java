package Rendevous;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;

public class Main {
	 static Event [] events=new Event[2000];
     static Participant[] participant=new Participant[2000000];
	 static Event[] eventsHeap=new Event[1000];  
	 static int heapsize=0;
	
public static void main(String args[]) throws Exception{
	try{
        BufferedReader BR = new BufferedReader(new FileReader("Query.txt"));
       String S="New String";
        while(S!=null){
             S = BR.readLine();
             if(S==null)
            	 break;
             String [] queries=  S.split(" ");
            if(queries[0].equals("ADD")){
            	 if(queries[1].equals("PARTICIPANT")){
            		 if(queries.length==5)
            		    addParticipant(queries[2].split(",")[0],queries[3].split(",")[0],queries[4]);
            		 else{
            			 addParticipant(queries[2].split(",")[0],queries[3].split(",")[0],queries[4].concat(" ".concat(queries[5])));            			 
            	    //    System.out.println(queries[4].concat(" ".concat(queries[5])));
            			 }
            	 }
            	 else if(queries[1].equals("EVENT")){
            		 if(queries.length==5)
            		    addEvent(queries[2].split(",")[0],queries[3].split(",")[0],queries[4]);
            		 else{
            			 addEvent(queries[2].split(",")[0],queries[3].split(",")[0],queries[4].concat(" ".concat(queries[5])));
             	     //   System.out.println(queries[4].concat(" ".concat(queries[5]))); 
            		 }
            	 }
            	 else{
            		 addparticipantToEvent(queries[1].split(",")[0],queries[2]);
            	 }
             }
             if(queries[0].equals("DELETE")){
            	 if(queries[1].equals("EVENT")){
            		 if(queries[2].equals("PARTICIPANT")){
            			 deleteparticipantfromEvent(queries[3].split(",")[0],queries[4]);
            		 }
            		 else
            		 cancelEvent(queries[2]);
            	 }
            	 else {
            		 deleteParticipant(queries[2]); 
            	 }
             }
             if(queries[0].equals("UPDATE")){
            	updateScore(queries[2].split(",")[0],queries[3].split(",")[0],Integer.parseInt(queries[4])); 
             }
             if(queries[0].equals("TOP3")){
            	 if(queries.length==1){
            		 printTop3();
            	 }
            	 else{
            		 printTop3inEvent(queries[3]);
            	 }
             }
         //    int i=0;
          /*   while(i<queries.length){
            System.out.println(queries[i]);
            i++;
             }*/
        }
        BR.close();
    }catch (FileNotFoundException e){
        e.printStackTrace();
    }catch (IOException e) {
        e.printStackTrace();
    }
	  /*  addEvent("E1", "Jeopardy", "Quizzing");
	    addEvent("E2", "Sports Quiz", "Quizzing");
	    addEvent("E3", "Sports Quiz", "Quizzing");
	    addEvent("E4", "Jeopardy", "Quizzing");
	    addEvent("E5", "Sports Quiz", "Quizzing");
	    addEvent("E6", "Sports Quiz", "Quizzing");
	    addParticipant("P1", "Vijay", "BCCI");
	    addParticipant("P2", "Vijay", "BCCI");
	    addParticipant("P3", "Ajay", "BCCI");
        addparticipantToEvent("P1","E1");
        addparticipantToEvent("P1","E2");
        addparticipantToEvent("P1","E3");
        addparticipantToEvent("P2","E1");
        addparticipantToEvent("P2","E2");
        addparticipantToEvent("P2","E3");
        addparticipantToEvent("P3","E1");
        addparticipantToEvent("P3","E2");
        addparticipantToEvent("P3","E3");
        updateScore("P1","E1",8);
        updateScore("P1","E2",4);
        updateScore("P1","E3",5);
        updateScore("P2","E1",11);
        updateScore("P2","E2",45);
        updateScore("P2","E3",34);
        updateScore("P3","E1",22);
        updateScore("P3","E2",10);
        updateScore("P3","E3",3);
        deleteParticipant("P1");
        deleteParticipant("P2");
        addParticipant("P1", "Vijay", "BCCI");
	    addParticipant("P2", "Vijay", "BCCI");
	    addparticipantToEvent("P1","E1");
	    addparticipantToEvent("P1","E2");
	    addparticipantToEvent("P1","E3");
	    addparticipantToEvent("P2","E1");
	    addparticipantToEvent("P2","E2");
	    addparticipantToEvent("P2","E3");
	    updateScore("P1","E1",8);
	    updateScore("P1","E2",4);
	    updateScore("P1","E3",5);
	    updateScore("P2","E1",11);
	    updateScore("P2","E2",45);
	    updateScore("P2","E3",34);
	    updateScore("P3","E1",22);
	    updateScore("P3","E2",10);
	    updateScore("P3","E3",3);    
		printTop3inEvent("E1");
	    printTop3();	
		cancelEvent("E1");
		cancelEvent("E3");
        deleteparticipantfromEvent("P2","E2");
        printTop3();*/
      //  printTop3inEvent("E1");
   	    
	
}
private static void cancelEvent(String eventID) throws Exception{
	Event p=events[hash(eventID)];
	if(p==null){
	//	System.out.println("Event not present");
	    throw new Exception();
	}
	if(p.eventID.equals(eventID)){
		events[hash(eventID)]=p.next;
		removefromHeap(eventID);
		return;
	}
	else{
		while(p.next!=null){
			if(p.next.eventID.equals(eventID)){
				removefromHeap(eventID);
				p.next=p.next.next;
				return;
			}
			p=p.next;
		}
		//System.out.println("Event not present");
	    throw new Exception();	
	}
}
private static void removefromHeap(String eventID) {
	for(int i=0;i<heapsize;i++){
		if(eventsHeap[i].eventID.equals(eventID)){
			eventsHeap[i].position=-1;
			eventsHeap[i]=eventsHeap[heapsize-1];
			eventsHeap[i].position=i;
			eventsHeap[heapsize-1]=null;
			heapsize--;
			ShiftDown(i);
			return;
			}
	}
	
}
private static void ShiftDown(int i) {
	int lchild,rchild;
	lchild=2*i+1;rchild=2*i+2;
	if(lchild>=heapsize){
		return;
	}
	try {
		while((lchild<heapsize && eventsHeap[i].topscore<eventsHeap[lchild].topscore) ||(rchild<heapsize && eventsHeap[i].topscore<eventsHeap[rchild].topscore)){
			if(rchild>=heapsize ||eventsHeap[lchild].topscore>eventsHeap[rchild].topscore){
				Event temp=eventsHeap[i];
				eventsHeap[i]=eventsHeap[lchild];
				eventsHeap[lchild]=temp;
				eventsHeap[i].position=i;
				eventsHeap[lchild].position=lchild;
				i=lchild;
				lchild=2*i+1;rchild=2*i+2;			 	
			}
			else{
				Event temp=eventsHeap[i];
				eventsHeap[i]=eventsHeap[rchild];
				eventsHeap[rchild]=temp;
				eventsHeap[i].position=i;
				eventsHeap[rchild].position=rchild;
				i=rchild;
				lchild=2*i+1;rchild=2*i+2;
			}
		}
	} catch (Exception e) {
		e.printStackTrace();
	}
}
private static void addEvent(String eventID,String eventName,String eventDescription) throws Exception{
	Event E=new Event(eventID,eventName,eventDescription);
	Event p=events[hash(E.eventID)];
	if(p==null){
		events[hash(E.eventID)]=E;
		eventsHeap[heapsize]=E;
		eventsHeap[heapsize].position=heapsize;
		Shiftup(heapsize);
		heapsize++;
		return;
	}
	while(p.next!=null){
		if(p.eventID.equals(eventID)){
			//System.out.println(eventID+" already in syatem");
			throw new Exception();
		}
		p=p.next;
	}
	p.next=E;
	eventsHeap[heapsize]=E;
	eventsHeap[heapsize].position=heapsize;
	Shiftup(heapsize);
	heapsize++;
}
private static void Shiftup(int i) {
	if(i==0)
		return;
try {
	while(i>0 && eventsHeap[(i-1)/2].topscore<eventsHeap[i].topscore ){
		Event temp=eventsHeap[(i-1)/2];
		eventsHeap[(i-1)/2]=eventsHeap[i];
		eventsHeap[i]=temp;
		eventsHeap[i].position=i;
		eventsHeap[(i-1)/2].position=(i-1)/2;
		i=(i-1)/2;
	}
} catch (Exception e) {
	e.printStackTrace();
}
}
public static int  hash(String eventID) {
	int prime=100000007,x=263;
	int hash = 0;
    for (int i = eventID.length() - 1; i >= 0; i--)
     hash = (hash * x + eventID.charAt(i)) % prime;
    return hash%2000;
}
private static void printTop3() throws Exception{ //if score of all player after Ist is same then changes are required
	int first=0,second=1,third=2;
	ArrayList<Integer>eventReferrence=new ArrayList<Integer>();
	ArrayList<Participant> top=new ArrayList<Participant>();
  
  for(int i=0;i<=6 && i<heapsize;i++){
	  ArrayList<Integer> eventToppers=eventsHeap[i].giveTop3();
	  int j=0;
	  while(j<eventToppers.size()){
	    top.add(eventsHeap[i].participants[eventToppers.get(j)]);
	    eventReferrence.add(i);
	    j++;
	    }	
    }
  if(top.size()==0)
	  return;
  if(top.size()==1){
	 System.out.println(top.get(0).participantID+", "+top.get(0).participantName+", "+top.get(0).universityName+", "+eventsHeap[eventReferrence.get(0)].eventID+", "+top.get(0).score(eventsHeap[eventReferrence.get(0)].eventID)); 
	 return; }
  if(top.size()==2){
		System.out.println(top.get(first).participantID+", "+top.get(first).participantName+", "+top.get(first).universityName+", "+eventsHeap[eventReferrence.get(first)].eventID+", "+top.get(first).score(eventsHeap[eventReferrence.get(first)].eventID)); 
		System.out.println(top.get(second).participantID+", "+top.get(second).participantName+", "+top.get(second).universityName+", "+eventsHeap[eventReferrence.get(second)].eventID+", "+top.get(second).score(eventsHeap[eventReferrence.get(second)].eventID)); 
		return;}

  try {  if(top.get(second).score(eventsHeap[eventReferrence.get(second)].eventID)<top.get(third).score(eventsHeap[eventReferrence.get(third)].eventID)){
			int temp=second;
			second=third;
			third=temp;}
      } catch (Exception e) {
         e.printStackTrace();}

  if(top.size()==3){
	System.out.println(top.get(first).participantID+", "+top.get(first).participantName+", "+top.get(first).universityName+", "+eventsHeap[eventReferrence.get(first)].eventID+", "+top.get(first).score(eventsHeap[eventReferrence.get(first)].eventID)); 
	System.out.println(top.get(second).participantID+", "+top.get(second).participantName+", "+top.get(second).universityName+", "+eventsHeap[eventReferrence.get(second)].eventID+", "+top.get(second).score(eventsHeap[eventReferrence.get(second) ].eventID)); 
	System.out.println(top.get(third).participantID+", "+top.get(third).participantName+", "+top.get(third).universityName+", "+eventsHeap[eventReferrence.get(third)].eventID+", "+top.get(third).score(eventsHeap[eventReferrence.get(third)].eventID)); 
	return;}  

  for(int i=3;i<top.size();i++){
	  try {if(top.get(i).score(eventsHeap[eventReferrence.get(i)].eventID)>top.get(third).score(eventsHeap[eventReferrence.get(third)].eventID)){
				third=i;
				if(top.get(second).score(eventsHeap[eventReferrence.get(second)].eventID)<top.get(third).score(eventsHeap[eventReferrence.get(third)].eventID)){
		    		int temp=second;
		    		second=third;
		    		third=temp;
		    	}
			}
	       } catch (Exception e) {
	         e.printStackTrace();
	           }
	     }
  try {
   if(top.get(third).score(eventsHeap[eventReferrence.get(third)].eventID)==top.get(second).score(eventsHeap[eventReferrence.get(second)].eventID)){
	 int i=0;
	 ArrayList<Participant> tmp=new ArrayList<Participant>();
	 ArrayList<Integer> TmpeventReferrence=new ArrayList<Integer>();
	 tmp.add( top.get(first));tmp.add(top.get(second));tmp.add(top.get(third));
	 TmpeventReferrence.add(eventReferrence.get(first)); TmpeventReferrence.add(eventReferrence.get(second)); TmpeventReferrence.add(eventReferrence.get(third));
	 while(i<top.size() && top.get(i).score(eventsHeap[eventReferrence.get(i)].eventID)==top.get(second).score(eventsHeap[eventReferrence.get(second)].eventID)){
	   if(i==first || i==second || i==third){
	     i++;
	     continue;
	    }
	   tmp.add(top.get(i));
	   TmpeventReferrence.add(eventReferrence.get(i));
	   i++;
	   }
     top=tmp;
     eventReferrence=TmpeventReferrence;
     }
   else{
	   ArrayList<Participant> tmp=new ArrayList<Participant>();
		 ArrayList<Integer> TmpeventReferrence=new ArrayList<Integer>();
		 tmp.add( top.get(first));tmp.add(top.get(second));tmp.add(top.get(third));
		 TmpeventReferrence.add(eventReferrence.get(first)); TmpeventReferrence.add(eventReferrence.get(second)); TmpeventReferrence.add(eventReferrence.get(third));
		 top=tmp;
	     eventReferrence=TmpeventReferrence;
   }
   }catch (Exception e) {
	e.printStackTrace();
}
  
  int j=0;
  while(j<top.size()){
	  try {
		System.out.println(top.get(j).participantID+", "+top.get(j).participantName+", "+top.get(j).universityName+", "+eventsHeap[eventReferrence.get(j)].eventID+", "+eventsHeap[eventReferrence.get(j)].eventName+", "+top.get(j).score(eventsHeap[eventReferrence.get(j)].eventID));
	   j++;
	  } catch (Exception e) {
		e.printStackTrace();
	}
  }
	
}
private static Event searchEvent(String eventID) throws Exception{
	Event p=events[hash(eventID)];
    
	while(p!=null){
    	if(p.eventID.equals(eventID))
    		return p;
    	p=p.next;
	}
//	System.out.println("Event not present");
    throw new Exception();
    
}
private static void addParticipant(String participantID,String participantName,String universityName){
	Participant p=new Participant();
	p.participantID=participantID;p.participantName=participantName;p.universityName=universityName;
   
	Participant x=participant[hash2(p.participantID)];
	if(x==null){
		participant[hash2(p.participantID)]=p;
		return ;//p;
	}
	if(p.participantID.equals(participantID)){
		//	System.out.println("already registered in System");
			return;// p;
			}
	while(x.next!=null){
		x=x.next;
		if(x.participantID.equals(participantID)){
			//	System.out.println("already registered in System");
				return ;//x;
			}
	}
	x.next=p;
	return ;//p;
}
private static void deleteParticipant(String participantID) throws Exception{
	Participant x=participant[hash2(participantID)];
	if(x==null){
	 //  System.out.println(participantID+" not present in system");
	   throw new Exception();
	}
	if(x.participantID.equals(participantID)){
		while(x.events.isEmpty()==false){			
				Event E=searchEvent(x.events.get(0));int topScore=E.topscore;
				E.deleteParticipant(participantID);
				if(E.topscore>topScore)
					Shiftup(E.position);
				if(E.topscore<topScore)
					ShiftDown(E.position);
				}
		participant[hash2(participantID)]=participant[hash2(participantID)].next;
	    return;
	}
	while(x.next!=null){
		if(x.next.participantID.equals(participantID)){
			while(x.next.events.isEmpty()==false){
					searchEvent(x.next.events.get(0)).deleteParticipant(participantID);
				}
			x.next=x.next.next;
			return;
		}
		x=x.next;
	}
	//System.out.println(participantID+" not present in system");	
}
public static int hash2(String participantID) {
	int prime=100000007,x=263;
	int hash = 0;
    for (int i = participantID.length() - 1; i >= 0; i--)
     hash = (hash * x + participantID.charAt(i)) % prime;
    return hash%2000000;
}
private static void updateScore(String participantID,String eventID,int finalscore){
	try {
		Event E=searchEvent(eventID);int topScore=E.topscore;
		E.updateScore(participant[hash2(participantID)],finalscore);
		if(E.topscore>topScore)
			Shiftup(E.position);
		if(E.topscore<topScore)
			ShiftDown(E.position);
	} catch (Exception e) {
	   e.printStackTrace();
	}
 }
private static Participant searchParticipant(String participantID) throws Exception{
	Participant p=participant[hash2(participantID)];	
	if(p==null){
	//	System.out.println(participantID+" Not available in syatem");
		throw new Exception();
	}
	if(p.participantID.equals(participantID)){
		return p;
	}
	while(p.next!=null){
		p=p.next;
		if(p.participantID.equals(participantID)){
			return p;
		}		
	}
	throw new Exception();
}
private static void addparticipantToEvent(String participantID,String eventID){
	try {//not to update position initial score is 0
		searchEvent(eventID).addParticiapant(searchParticipant(participantID));
	} catch (Exception e) {
		e.printStackTrace();
	}
}
private static void deleteparticipantfromEvent(String participantID,String eventID) throws Exception{
	Event E=searchEvent(eventID);
	int topScore=E.topscore;
	E.deleteParticipant(participantID);
	if(E.topscore>topScore)
		Shiftup(E.position);
	if(E.topscore<topScore)
		ShiftDown(E.position);
}
private static Participant searchparticipant(String participantID) throws Exception{
	Participant p=participant[hash2(participantID)];
	if(p==null){
		//System.out.println(participantID+" not enrolled in system");
		throw new Exception();
	}
	while(p!=null){
		if(p.participantID.equals(participantID)){
			return p;
		}
		p=p.next;
	}
	//System.out.println(participantID+" not enrolled in system");
	throw new Exception();
}
private static void printTop3inEvent(String eventID) throws Exception{
	Event E=searchEvent(eventID);
	ArrayList<Integer> top3=E.giveTop3();
    int i=0;
    while(i<top3.size()){
     System.out.println(E.participants[top3.get(i)].participantID+", "+E.participants[top3.get(i)].participantName+", "+E.participants[top3.get(i)].universityName+", "+E.participants[top3.get(i)].score(eventID));
     i++;	
    }
}
}
