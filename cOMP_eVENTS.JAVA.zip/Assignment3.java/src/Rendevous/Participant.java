package Rendevous;

import java.util.ArrayList;

public class Participant {
	String participantID;
	String participantName;
	String universityName;
	Participant next;
	ArrayList<String> events=new ArrayList<String>();
	EventScore[] Events=new EventScore[2000];
	int score(String eventID) throws Exception{
		EventScore E= Events[Main.hash(eventID)];
		 if(E==null){
			 throw new Exception();
		 }
		 while(E!=null && E.eventID.equals(eventID)==false){
			 E=E.next;
		 }
		 if(E==null){
			 throw new Exception();
		 }
		 else
		  return E.score;
		 
		 
	}
	void updatescore(String eventID,int finalscore) throws Exception{// should be run only through updateScore in event class 
		EventScore E= Events[Main.hash(eventID)];
		 if(E==null){
			 throw new Exception();
		 }
		 while( E!=null && E.eventID!=eventID ){
			 E=E.next;
		 }
		 if(E.eventID.equals(eventID)){
			 E.score=finalscore;
			 return;
		 }
		 throw new Exception();
		}
	void addEvent(String eventID) throws Exception{
		events.add(eventID);
		EventScore E=new EventScore();
		E.eventID=eventID;
		EventScore p=Events[Main.hash(eventID)];
		if(p==null){
			Events[Main.hash(eventID)]=E;
			return;
		}
		while(p.next!=null){
			if(p.eventID.equals(eventID)){
				System.out.println(participantID+" is alredy registered in"+eventID);
			    throw new Exception();
			}
			p=p.next;
		}
		if(p.eventID.equals(eventID)){
			System.out.println(participantID+" is alredy registered in"+eventID);
		    throw new Exception();
		}
		p.next=E;
	}
	class EventScore{
		String eventID;
		int score=0;
		int position;
		EventScore next;
	}
    void deleteEvent(String eventID) throws Exception{
    	events.remove(eventID);
    	EventScore E=Events[Main.hash(eventID)];
    	if(E.eventID.equals(eventID)){
    		Events[Main.hash(eventID)]=Events[Main.hash(eventID)].next;
    		return;
    	}
    	while(E.next.eventID!=eventID){
    		if(E.next.eventID.equals(eventID)){
    			E.next=E.next.next;
    			return;
    		}
    	}
    	throw new Exception();
    }
    EventScore searchEvent(String eventID) throws Exception{
    	EventScore E= Events[Main.hash(eventID)];
		 if(E==null){
			 throw new Exception();
		 }
		 while(E.eventID!=eventID &&E!=null){
			 E=E.next;
		 }
		 if(E.eventID.equals(eventID)){
			 return E; 
		 }
		 throw new Exception();
		}
    
}
