package Rendevous;

import java.util.ArrayList;

public class Event {
	String eventID;
	int position=-1;
	String eventName;
	String eventDescription;
	int size=0,topscore=0;
	Participant[] participants=new Participant[1];
	Event next;	
	Event(String eventID,String eventName,String eventDescription){
		this.eventID=eventID;
		this.eventDescription=eventDescription;
		this.eventName=eventName;
	}
	void addParticiapant(Participant p) throws Exception{
	  p.addEvent(eventID);
	  if(2*(size+1)>participants.length)
		doublesize();
	  participants[size]=p;
	  p.searchEvent(eventID).position=size;
	  Shiftup(size);
	  size++;
	}
	private void Shiftup(int i) throws Exception {
		topscore=participants[0].score(eventID);
		if(i==0)
			return;
		int parent=(i-1)/2;
		while(i>0 && participants[parent].score(this.eventID)<participants[i].score(this.eventID)){
			Participant temp=participants[parent];
				participants[parent]=participants[i];
				participants[i]=temp;
				participants[i].searchEvent(eventID).position=i;participants[parent].searchEvent(eventID).position=parent;
				i=parent;
			    parent=(i-1)/2;
		}	
		topscore=participants[0].score(eventID);
	}
	private void doublesize(){
		Participant[] p=new Participant[2*participants.length];
		int i=0;
		while(i<participants.length){
			p[i]=participants[i];
			i++;
		}
		participants=p;
	}
    void deleteParticipant(String participantID) throws Exception{               
		for(int i=0;i<size;i++){
			if(participants[i].participantID.equals(participantID)){
				participants[i].deleteEvent(eventID);
				participants[i]=participants[size-1];
				if(i!=size-1)
				participants[i].searchEvent(eventID).position=i;
				participants[size-1]=null;
				size--;
				if(size==0){
					topscore=0;
					return;
				}
			ShiftDown(i);
	    	return;
			}
		}
	}
    public ArrayList<Integer> giveTop3() throws Exception{
    	ArrayList<Integer> top=new ArrayList<Integer>();
    	if(size<=3){
    		for(int i=0;i<size;i++){
    			top.add(i);
    			}
    		if(size<3)
    			return top;
    		}
    	int first=0,second=1,third=2,temp;
    	
    	if(participants[second].score(this.eventID)<participants[third].score(this.eventID)){
    		temp=second;
    		second=third;
    		third=temp;
    	}
    	
    	for(int i=3;i<=6 && i<size;i++){
			if(participants[i].score(this.eventID)>participants[third].score(this.eventID)){
				third=i;
				if(participants[second].score(this.eventID)<participants[third].score(this.eventID)){
		    		temp=second;
		    		second=third;
		    		third=temp;
		    	}
			}
		}
    	try{
    	   	top.set(0, 0);}catch(IndexOutOfBoundsException e){
    	   		top.add(0);
    	   	}
    	try{
   	top.set(1, second);}catch(IndexOutOfBoundsException e){
   		top.add(second);
   	}
    	try{
    	   	top.set(2, third);}catch(IndexOutOfBoundsException e){
    	   		top.add(third);
    	   	}
    	 
    	
    	
    if(participants[third].score(this.eventID)==participants[second].score(this.eventID)){
	   if(second!=third*2+1 && second!=third*2+2)// second is not a child of third
	    getEqualParticipants(top,second,second);
	   if(third!=2*second+1 && third!=second*2+2) // third is not a child of second
	    getEqualParticipants(top,third,third);
     }
   return top;
    }
    private void getEqualParticipants(ArrayList<Integer> top, int second, int second2) throws Exception {
    	if(second2>=size)
    		return;
	if(participants[second].score(eventID)==participants[second2].score(eventID)){
		if(second2!=second)
		top.add(second2);
		getEqualParticipants(top,second,(second2*2)+1);
		getEqualParticipants(top,second,(second2*2)+1);// TODO Auto-generated method stub
	}
		
	}
	private void ShiftDown(int i) throws Exception{
		int lchild,rchild;
		lchild=2*i+1;rchild=2*i+2;
    	if(lchild>=size){
    		topscore=participants[0].score(eventID);
			return;
		}
    	while((lchild<size && participants[i].score(this.eventID)<participants[lchild].score(this.eventID)) ||(rchild<size && participants[i].score(this.eventID)<participants[rchild].score(this.eventID))){
    		if(rchild>=size ||participants[lchild].score(this.eventID)>participants[rchild].score(this.eventID)){
    			Participant temp=participants[i];
				participants[i]=participants[lchild];
				participants[lchild]=temp;
				participants[i].searchEvent(eventID).position=i;participants[lchild].searchEvent(eventID).position=lchild;
				i=lchild;
				lchild=2*i+1;rchild=2*i+2;			 	
    		}
    		else{
				Participant temp=participants[i];
				participants[i]=participants[rchild];
				participants[rchild]=temp;
				participants[i].searchEvent(eventID).position=i;participants[rchild].searchEvent(eventID).position=rchild;
				i=rchild;
				lchild=2*i+1;rchild=2*i+2;
			}
    	}
    	topscore=participants[0].score(eventID);
    }
	void updateScore(Participant p,int score) throws Exception{
			int s=p.score(this.eventID);
				p.updatescore((this.eventID), score);
				if(score>s){
					Shiftup(p.searchEvent(eventID).position);
					}
				else if(score<s){
					ShiftDown(p.searchEvent(eventID).position);
				}
				else return;
			
	
		
	}
	
}
